//Menu
function toggleSideMenu() {
    const sideMenu = document.getElementById('sideMenu')
    if (sideMenu.style.marginLeft === "0px") {
        sideMenu.style.marginLeft = "-250px"
    }
    else {
        climate.style.display = "none"
        sideMenu.style.marginLeft = "0"
    }
}

function toggleDrop(id) {
    if (id.style.display === "block") {
        id.style.display = "none"
    }
    else {
        id.style.display = "block"
    }
}

//Form

function processJSON(json) {
	console.log(json);
	const result = document.querySelector('#result');
    const form = document.querySelector('form')
	result.textContent = 'Sucsess ' + json.fname + ' ' + json.lname + '! Updates will be sent to ' + json.email
    form.reset();
}

function onError(error) {
    console.log(error);
}

function onResponse(response) {
    console.log(response.status);
    response.json().then(processJSON); 
}

function formatMessage(fname, lname, email, comments){
	let message = {
		fname: fname,
		lname: lname,
        email: email,
        comments: comments
	}
	return JSON.stringify(message);
}

jQuery("form").submit(async function onSubmit(e) {
    e.preventDefault();
    
    const fname = document.querySelector('#fname').value;
    const lname = document.querySelector('#lname').value;
    const email = document.querySelector('#email').value;
    const comments = document.querySelector('#comments').value;

    const serializedMessage = formatMessage(fname, lname, email, comments);
    console.log(serializedMessage);
    fetch('/form', {  
        method: 'POST',  
        headers: {
            'Content-Type': 'application/json'
        },
        body:serializedMessage
    })
    .then(onResponse, onError);
    e.stopPropagation();
})

// reference for "$("html").toggleClass("inversed");" : https://stackoverflow.com/questions/35271713/invert-complete-webpage-colors-and-reverse-them-with-single-toggle-button
function toggleInverse() {
    $("html").toggleClass("inversed");
}