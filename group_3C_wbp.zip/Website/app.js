const env = process.env.NODE_ENV || 'development';
const path = require('path');
const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const jsonParser = bodyParser.json();

app.use(express.static(path.join(__dirname, 'public')));

app.get('/', function(req, res) {
	res.set({ status:200,'Content-Type': 'text/html'});
})

app.post('/form', jsonParser, function(req, res){
	console.log(req.body);
	const fname = req.body.fname;
	const lname = req.body.lname;
    const email = req.body.email;
    const comments = req.body.comments;
	response = {
		fname: fname,
		lname: lname,
        email: email,
        comments: comments
	}
	res.json(response);
})

app.listen(3000, function(){
	console.log('Listening on port 3000...')
});
